package com.wastewise.pickup.model.enums;

public enum PickUpStatus {
    SCHEDULED,
    IN_PROGRESS,
    COMPLETED
}
