import React, { createContext, useContext, useState, useEffect } from 'react';
import { authAPI, setAuthToken, clearAuthToken } from '../utils/api'; // ✅ Make sure you have this

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for stored user on app load
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  // ✅ Updated login
  const login = async (empId, password) => {
    setIsLoading(true);
    try {
      const response = await authAPI.login({ workerId: empId, password }); // ✅ fixed key name
  
      const token = response.token;
      const role = response.role;
  
      if (!token || !role) throw new Error('Invalid login response');
  
      const userData = {
        empId,
        name: `User ${empId}`,
        role
      };
  
      setAuthToken(token);
      setUser(userData);
      localStorage.setItem('currentUser', JSON.stringify(userData));
      setIsLoading(false);
      console.log(userData);
      return userData;
  
    } catch (error) {
      setIsLoading(false);
      throw new Error(error.message || 'Login failed');
    }
  };
  

  const logout = () => {
    clearAuthToken(); // ✅ clear token also
    setUser(null);
    localStorage.removeItem('currentUser');
  };

  const value = {
    user,
    isLoading,
    login,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
