import React, { createContext, useContext, useState, useEffect } from 'react';
import { vehiclesAPI, handleApiError } from '../utils/api';
import { useAuth } from './AuthContext'; // Added for consistency like RouteContext

const VehicleContext = createContext();

/**
 * Custom hook to access the Vehicle context
 */
export const useVehicle = () => {
  const context = useContext(VehicleContext);
  if (!context) {
    throw new Error('useVehicle must be used within a VehicleProvider');
  }
  return context;
};

/**
 * VehicleProvider to wrap the app and provide vehicle data
 */
export const VehicleProvider = ({ children }) => {
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const { user } = useAuth(); // Ensures vehicles only load when logged in (like RouteContext)

  /**
   * Fetch all vehicles from backend
   */
  const fetchVehicles = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await vehiclesAPI.getAll();
      setVehicles(response.data || response || []);
    } catch (err) {
      const errorMessage = handleApiError(err);
      setError(errorMessage);
      console.error('Error fetching vehicles:', errorMessage);
      setVehicles([]);
    } finally {
      setLoading(false);
    }
  };

  // Fetch after login
  useEffect(() => {
    if (user) {
      fetchVehicles();
    }
  }, [user]);

  const createVehicle = async (vehicleData) => {
    try {
      setLoading(true);
      setError(null);
      const response = await vehiclesAPI.create(vehicleData);
      await fetchVehicles();
      return response.data;
    } catch (err) {
      const errorMessage = handleApiError(err);
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const updateVehicle = async (vehicleId, updatedData) => {
    try {
      setLoading(true);
      setError(null);
      const response = await vehiclesAPI.update(vehicleId, updatedData);
      await fetchVehicles();
      return response.data;
    } catch (err) {
      const errorMessage = handleApiError(err);
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const deleteVehicle = async (vehicleId) => {
    try {
      setLoading(true);
      setError(null);
      await vehiclesAPI.delete(vehicleId);
      await fetchVehicles();
    } catch (err) {
      const errorMessage = handleApiError(err);
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const getVehicleById = async (vehicleId) => {
    try {
      const response = await vehiclesAPI.getById(vehicleId);
      return response.data || response;
    } catch (err) {
      const errorMessage = handleApiError(err);
      console.error('Error fetching vehicle by ID:', errorMessage);
      throw new Error(errorMessage);
    }
  };

  const getPickupTrucks = async () => {
    try {
      const response = await vehiclesAPI.getPickupTrucks();
      return response.data || response || [];
    } catch (err) {
      const errorMessage = handleApiError(err);
      console.error('Error fetching pickup trucks:', errorMessage);
      return [];
    }
  };

  const getRouteTrucks = async () => {
    try {
      const response = await vehiclesAPI.getRouteTrucks();
      return response.data || response || [];
    } catch (err) {
      const errorMessage = handleApiError(err);
      console.error('Error fetching route trucks:', errorMessage);
      return [];
    }
  };

  const getVehiclesByType = (type) => {
    return vehicles.filter(vehicle => vehicle.type === type);
  };

  const getVehiclesByStatus = (status) => {
    return vehicles.filter(vehicle => vehicle.status === status);
  };

  const getAvailableVehicles = () => {
    return vehicles.filter(vehicle => vehicle.status === 'available');
  };

  const value = {
    vehicles,
    loading,
    error,
    fetchVehicles,
    createVehicle,
    updateVehicle,
    deleteVehicle,
    getVehicleById,
    getPickupTrucks,
    getRouteTrucks,
    getVehiclesByType,
    getVehiclesByStatus,
    getAvailableVehicles
  };

  return (
    <VehicleContext.Provider value={value}>
      {children}
    </VehicleContext.Provider>
  );
};
