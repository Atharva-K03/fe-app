import React, { createContext, useContext, useState, useEffect } from 'react';
import { assignmentsAPI, handleApiError } from '../utils/api';
import { useAuth } from './AuthContext'; // Match RouteContext

const AssignmentContext = createContext();

/**
 * Custom hook to access AssignmentContext
 */
export const useAssignment = () => {
  const context = useContext(AssignmentContext);
  if (!context) {
    throw new Error('useAssignment must be used within an AssignmentProvider');
  }
  return context;
};

/**
 * Provider to wrap app with assignment data logic
 */
export const AssignmentProvider = ({ children }) => {
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const { user } = useAuth(); // Exactly like RouteContext

  /**
   * Fetch assignments from backend API
   */
  const fetchAssignments = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await assignmentsAPI.getAll();
      setAssignments(response.data || response || []);
    } catch (err) {
      const errorMessage = handleApiError(err);
      setError(errorMessage);
      console.error("Error fetching assignments:", errorMessage);
      setAssignments([]);
    } finally {
      setLoading(false);
    }
  };

  // Only fetch after login like in RouteContext
  useEffect(() => {
    if (user) {
      fetchAssignments();
    }
  }, [user]);

  const createAssignment = async (assignmentData) => {
    try {
      setLoading(true);
      setError(null);
      const response = await assignmentsAPI.create(assignmentData);
      await fetchAssignments();
      return response.data;
    } catch (err) {
      const errorMessage = handleApiError(err);
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const updateAssignment = async (assignmentId, updatedData) => {
    try {
      setLoading(true);
      setError(null);
      const response = await assignmentsAPI.update(assignmentId, updatedData);
      await fetchAssignments();
      return response.data;
    } catch (err) {
      const errorMessage = handleApiError(err);
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const deleteAssignment = async (assignmentId) => {
    try {
      setLoading(true);
      setError(null);
      await assignmentsAPI.delete(assignmentId);
      await fetchAssignments();
    } catch (err) {
      const errorMessage = handleApiError(err);
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const getAssignmentById = async (assignmentId) => {
    try {
      const response = await assignmentsAPI.getById(assignmentId);
      return response.data || response;
    } catch (err) {
      const errorMessage = handleApiError(err);
      console.error('Error fetching assignment by ID:', errorMessage);
      throw new Error(errorMessage);
    }
  };

  // Helpers (optional analytics)
  const getAssignmentsByRoute = (routeId) =>
    assignments.filter(a => a.routeId === routeId);

  const getAssignmentsByVehicle = (vehicleId) =>
    assignments.filter(a => a.vehicleId === vehicleId);

  const getAssignmentsByWorker = (workerId) =>
    assignments.filter(
      a => a.worker1Id === workerId || a.worker2Id === workerId
    );

  const getAssignmentsByStatus = (status) =>
    assignments.filter(a => a.status === status);

  const getActiveAssignments = () =>
    assignments.filter(a => a.status === 'active');

  const getAssignmentStats = () => {
    const totalAssignments = assignments.length;
    const activeAssignments = getActiveAssignments().length;
    const uniqueRoutes = new Set(assignments.map(a => a.routeId)).size;
    const uniqueVehicles = new Set(assignments.map(a => a.vehicleId)).size;

    return {
      totalAssignments,
      activeAssignments,
      uniqueRoutes,
      uniqueVehicles
    };
  };

  const value = {
    assignments,
    loading,
    error,
    fetchAssignments,
    createAssignment,
    updateAssignment,
    deleteAssignment,
    getAssignmentById,
    getAssignmentsByRoute,
    getAssignmentsByVehicle,
    getAssignmentsByWorker,
    getAssignmentsByStatus,
    getActiveAssignments,
    getAssignmentStats
  };

  return (
    <AssignmentContext.Provider value={value}>
      {children}
    </AssignmentContext.Provider>
  );
};
