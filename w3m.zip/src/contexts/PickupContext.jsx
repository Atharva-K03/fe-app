import React, { createContext, useContext, useState, useEffect } from 'react';
import { pickupsAPI, handleApiError } from '../utils/api';
import { useAuth } from './AuthContext';

// Import hooks from your other contexts
import { useZone } from './ZoneContext';         // Assuming ZoneContext.js exports useZone
import { useRoute } from './RouteContext';       // Assuming RouteContext.js exports useRoute
import { useAssignment } from './AssignmentContext'; // Assuming AssignmentContext.js exports useAssignment
import { useVehicle } from './VehicleContext';     // Assuming VehicleContext.js exports useVehicle
import { useWorker } from './WorkerContext';       // Assuming WorkerContext.js exports useWorker

const PickupContext = createContext();

export const usePickup = () => {
  const context = useContext(PickupContext);
  if (!context) {
    throw new Error('usePickup must be used within a PickupProvider');
  }
  return context;
};

export const PickupProvider = ({ children }) => {
  const [pickups, setPickups] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const { user } = useAuth();

  // Consume other contexts here
  const { zones, loading: zonesLoading, error: zonesError, fetchZones } = useZone();
  const { routes, loading: routesLoading, error: routesError, fetchRoutes } = useRoute();
  const { assignments, loading: assignmentsLoading, error: assignmentsError, fetchAssignments } = useAssignment();
  const { vehicles, loading: vehiclesLoading, error: vehiclesError, fetchVehicles } = useVehicle();
  const { workers, loading: workersLoading, error: workersError, fetchWorkers } = useWorker();

  // You can derive a combined loading state if necessary
  const combinedLoading = loading || zonesLoading || routesLoading || assignmentsLoading || vehiclesLoading || workersLoading;
  // And a combined error state
  const combinedError = error || zonesError || routesError || assignmentsError || vehiclesError || workersError;


  const fetchPickups = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await pickupsAPI.getAll();
      setPickups(response.data || []);
    } catch (err) {
      const errorMessage = handleApiError(err);
      setError(errorMessage);
      console.error("Error fetching pickups:", errorMessage);
      setPickups([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchPickups();
      // Also fetch data from other contexts if they are needed immediately on login
      fetchZones();
      fetchRoutes();
      fetchAssignments();
      fetchVehicles();
      fetchWorkers();
    }
  }, [user]); // Re-run when user changes

  const createPickup = async (pickupData) => {
    try {
      setLoading(true);
      setError(null);
      const response = await pickupsAPI.create(pickupData);
      await fetchPickups(); // Re-fetch all pickups to ensure fresh data
      return response.data;
    } catch (err) {
      const errorMessage = handleApiError(err);
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const updatePickup = async (pickupId, updatedData) => {
    try {
      setLoading(true);
      setError(null);
      const response = await pickupsAPI.update(pickupId, updatedData);
      await fetchPickups();
      return response.data;
    } catch (err) {
      const errorMessage = handleApiError(err);
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const deletePickup = async (pickupId) => {
    try {
      setLoading(true);
      setError(null);
      await pickupsAPI.delete(pickupId);
      await fetchPickups();
    } catch (err) {
      const errorMessage = handleApiError(err);
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // --- Functions that can now use data from other contexts ---

  // Example: Get pickups filtered by a specific zone
  const getPickupsByZone = (zoneId) => {
    // Ensure zones data is available and not empty before trying to find
    if (!zones || zones.length === 0) return [];
    const targetZone = zones.find(zone => zone.id === zoneId);
    if (!targetZone) return [];

    // Assuming your pickup objects have a 'zoneId' property
    return pickups.filter(pickup => pickup.zoneId === zoneId);
  };

  // Example: Assign a pickup to an available vehicle and worker within a route
  const assignPickupToRoute = async (pickupId, routeId, vehicleId, workerId) => {
    // You can now access `routes`, `vehicles`, `workers` directly here
    // Example: Validate if the route, vehicle, worker exist
    const selectedRoute = routes.find(r => r.id === routeId);
    const selectedVehicle = vehicles.find(v => v.id === vehicleId);
    const selectedWorker = workers.find(w => w.id === workerId);

    if (!selectedRoute || !selectedVehicle || !selectedWorker) {
      throw new Error("Invalid route, vehicle, or worker selection for assignment.");
    }

    // Call your assignment API
    // await assignmentsAPI.create({ pickupId, routeId, vehicleId, workerId });
    // Or, if assignments are handled by updating the pickup itself:
    await updatePickup(pickupId, { routeId, vehicleId, workerId, status: 'assigned' }); // Example

    // Then refetch assignments if necessary, or update locally
    await fetchAssignments(); // Assuming fetchAssignments updates the assignments state
  };

  // Replace dummy summary data with actual calculations based on 'pickups' state
  const getWeeklySummary = () => {
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    const weeklyPickups = pickups.filter(pickup => new Date(pickup.date) >= oneWeekAgo);

    const totalWeight = weeklyPickups.reduce((sum, pickup) => sum + (pickup.weight || 0), 0);
    const totalCollections = weeklyPickups.length;

    return { totalWeight, totalCollections };
  };

  const getMonthlySummary = () => {
    const oneMonthAgo = new Date();
    oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);

    const monthlyPickups = pickups.filter(pickup => new Date(pickup.date) >= oneMonthAgo);

    const totalWeight = monthlyPickups.reduce((sum, pickup) => sum + (pickup.weight || 0), 0);
    const totalCollections = monthlyPickups.length;

    return { totalWeight, totalCollections };
  };

  const getZoneDailyCollections = (zoneId, startDate, endDate) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999); // Include the whole end day

    const zonePickups = pickups.filter(pickup => {
      const pickupDate = new Date(pickup.date);
      return pickup.zoneId === zoneId && pickupDate >= start && pickupDate <= end;
    });

    // You might aggregate this data further, e.g., by day
    return zonePickups; // Or process into a daily summary
  };

  const getVehicleDailyWeight = (vehicleId, startDate, endDate) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);

    const vehiclePickups = pickups.filter(pickup => {
      const pickupDate = new Date(pickup.date);
      // Assuming pickup has vehicleId or can be linked via assignment
      // This is where 'assignments' context data might be crucial
      const relevantAssignment = assignments.find(
        assign => assign.pickupId === pickup.id && assign.vehicleId === vehicleId
      );
      return relevantAssignment && pickupDate >= start && pickupDate <= end;
    });

    // You might aggregate this data further, e.g., total weight per day for the vehicle
    return vehiclePickups; // Or process into a daily weight summary
  };


  const value = {
    // Pickup specific states and actions
    pickups,
    loading: combinedLoading, // Use combined loading state
    error: combinedError,     // Use combined error state
    createPickup,
    updatePickup,
    deletePickup,
    fetchPickups,

    // Expose states from other contexts (read-only for PickupContext consumers)
    zones,
    routes,
    assignments,
    vehicles,
    workers,

    // Enhanced functions using combined data
    getPickupsByZone,
    assignPickupToRoute, // Example of a new function
    getWeeklySummary,    // Now calculated from 'pickups'
    getMonthlySummary,   // Now calculated from 'pickups'
    getZoneDailyCollections, // Now calculated from 'pickups'
    getVehicleDailyWeight // Now calculated from 'pickups' and potentially 'assignments'
  };

  return (
    <PickupContext.Provider value={value}>
      {children}
    </PickupContext.Provider>
  );
};