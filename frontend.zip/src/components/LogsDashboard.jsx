import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
// Corrected relative paths for UI components (assuming they are in src/components/ui/)
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Badge } from '../components/ui/badge';

import {
  Weight,
  CalendarCheck,
  CalendarDays as CalendarDaysIcon,
  BarChart,
  ClipboardList,
  ArrowLeft, // For pagination
  ArrowRight, // For pagination
} from 'lucide-react';

import { format } from 'date-fns';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

// Corrected relative paths for contexts (assuming they are in src/contexts/)
import { useAuth } from '../contexts/AuthContext.jsx';
import { useTheme } from '../contexts/ThemeContext.jsx';
import { usePickup } from '../contexts/PickupContext.jsx';

const LogsDashboard = () => {
  const { logs, getWeeklySummary, getMonthlySummary, getZoneDailyCollections, getVehicleDailyWeight } = usePickup();
  const { theme } = useTheme();

  const [logType, setLogType] = useState('zone');
  const [selectedId, setSelectedId] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Separate states for Zone charts
  const [zoneCollectionsChartData, setZoneCollectionsChartData] = useState(null);
  const [zoneWeightChartData, setZoneWeightChartData] = useState(null);
  const [vehicleChartData, setVehicleChartData] = useState(null); // Vehicle chart remains single

  // Validation error states
  const [selectedIdError, setSelectedIdError] = useState('');
  const [startDateError, setStartDateError] = useState('');
  const [endDateError, setEndDateError] = useState('');

  // Pagination states for Recent Logs
  const [currentPage, setCurrentPage] = useState(0); // Backend pages are 0-indexed
  const [pageSize, setPageSize] = useState(10); // Matches backend default
  const [totalPages, setTotalPages] = useState(0);
  const [paginatedRecentLogs, setPaginatedRecentLogs] = useState([]);
  const [isLoadingRecentLogs, setIsLoadingRecentLogs] = useState(false);

  // Effect to clear selectedId, dates, and charts when logType changes
  useEffect(() => {
    setSelectedId('');
    setSelectedIdError('');
    setStartDate('');
    setStartDateError('');
    setEndDate('');
    setEndDateError('');
    setZoneCollectionsChartData(null);
    setZoneWeightChartData(null);
    setVehicleChartData(null);
  }, [logType]);

  // Simulate fetching paginated recent logs from backend
  useEffect(() => {
    const fetchRecentLogs = async () => {
      setIsLoadingRecentLogs(true);
      // Simulate API call delay (replace with actual API call in production)
      await new Promise(resolve => setTimeout(resolve, 500));

      // Simulate backend pagination logic
      const sortedLogs = [...logs].sort((a, b) => new Date(b.collectionStartTime) - new Date(a.collectionStartTime));
      const startIndex = currentPage * pageSize;
      const endIndex = startIndex + pageSize;
      const currentLogs = sortedLogs.slice(startIndex, endIndex);

      setPaginatedRecentLogs(currentLogs);
      setTotalPages(Math.ceil(sortedLogs.length / pageSize));
      setIsLoadingRecentLogs(false);
    };

    fetchRecentLogs();
  }, [currentPage, pageSize, logs]); // Re-fetch when page, size, or original logs change

  const weeklySummary = useMemo(() => getWeeklySummary(), [logs, getWeeklySummary]);
  const monthlySummary = useMemo(() => getMonthlySummary(), [logs, getMonthlySummary]);

  const getBadgeVariantAndColor = (status) => {
    switch (status.toLowerCase()) {
      case 'completed':
        return { variant: 'default', className: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' };
      case 'in progress':
        return { variant: 'default', className: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' };
      default:
        return { variant: 'default', className: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' };
    }
  };

  const handleGenerateReport = () => {
    // Reset previous errors
    setSelectedIdError('');
    setStartDateError('');
    setEndDateError('');

    let isValid = true;

    if (!selectedId.trim()) {
      setSelectedIdError(`Please enter a ${logType === 'zone' ? 'Zone' : 'Vehicle'} ID.`);
      isValid = false;
    }
    if (!startDate) {
      setStartDateError('Please select a start date.');
      isValid = false;
    }
    if (!endDate) {
      setEndDateError('Please select an end date.');
      isValid = false;
    }

    if (!isValid) {
      setZoneCollectionsChartData(null);
      setZoneWeightChartData(null);
      setVehicleChartData(null);
      return;
    }

    if (new Date(startDate) > new Date(endDate)) {
      setEndDateError('End date cannot be before start date.');
      isValid = false;
    }

    if (!isValid) {
      setZoneCollectionsChartData(null);
      setZoneWeightChartData(null);
      setVehicleChartData(null);
      return;
    }

    if (logType === 'zone') {
      const data = getZoneDailyCollections(selectedId, startDate, endDate);
      setZoneCollectionsChartData({
        labels: data.map(d => format(new Date(d.date), 'MMM dd')),
        datasets: [
          {
            label: 'Total Collections',
            data: data.map(d => d.collections), // Use numberOfCollections from dummy data
            backgroundColor: 'rgba(75, 192, 192, 0.6)',
          },
        ],
      });
      setZoneWeightChartData({
        labels: data.map(d => format(new Date(d.date), 'MMM dd')),
        datasets: [
          {
            label: 'Total Weight Collected (kg)',
            data: data.map(d => d.weight), // Use weightCollected from dummy data
            backgroundColor: 'rgba(153, 102, 255, 0.6)',
          },
        ],
      });
      setVehicleChartData(null); // Ensure vehicle chart is cleared
    } else if (logType === 'vehicle') {
      const data = getVehicleDailyWeight(selectedId, startDate, endDate);
      setVehicleChartData({
        labels: data.map(d => format(new Date(d.date), 'MMM dd')),
        datasets: [
          {
            label: 'Total Weight Collected (kg)',
            data: data.map(d => d.weight), // Use weightCollected from dummy data
            backgroundColor: 'rgba(255, 159, 64, 0.6)',
          },
        ],
      });
      setZoneCollectionsChartData(null); // Ensure zone charts are cleared
      setZoneWeightChartData(null);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="p-2 sm:p-4 lg:p-6 max-w-full overflow-hidden"
    >
      <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold mb-4 sm:mb-6 text-gray-800 dark:text-white">Admin Dashboard</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 lg:gap-6 mb-4 sm:mb-6 lg:mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.6 }}
        >
          <Card className="transition-all duration-200 hover:scale-105 hover:shadow-lg w-full">
            <CardContent className="p-3 sm:p-4 lg:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0 flex-1">
                  <p className="text-xs sm:text-sm font-medium text-muted-foreground truncate">Total Weight Collected Weekly</p>
                  <p className="text-lg sm:text-xl lg:text-2xl font-bold">{weeklySummary.totalWeight} kg</p>
                </div>
                <div className="p-2 sm:p-3 rounded-full bg-blue-100 dark:bg-blue-900 flex-shrink-0 ml-2">
                  <Weight className="h-4 w-4 sm:h-5 sm:w-5 lg:h-6 lg:w-6 text-blue-600 dark:text-blue-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
        >
          <Card className="transition-all duration-200 hover:scale-105 hover:shadow-lg w-full">
            <CardContent className="p-3 sm:p-4 lg:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0 flex-1">
                  <p className="text-xs sm:text-sm font-medium text-muted-foreground truncate">Total Collections Weekly</p>
                  <p className="text-lg sm:text-xl lg:text-2xl font-bold">{weeklySummary.totalCollections}</p>
                </div>
                <div className="p-2 sm:p-3 rounded-full bg-green-100 dark:bg-green-900 flex-shrink-0 ml-2">
                  <CalendarCheck className="h-4 w-4 sm:h-5 sm:w-5 lg:h-6 lg:w-6 text-green-600 dark:text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
        >
          <Card className="transition-all duration-200 hover:scale-105 hover:shadow-lg w-full">
            <CardContent className="p-3 sm:p-4 lg:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0 flex-1">
                  <p className="text-xs sm:text-sm font-medium text-muted-foreground truncate">Total Collections Monthly</p>
                  <p className="text-lg sm:text-xl lg:text-2xl font-bold">{monthlySummary.totalCollections}</p>
                </div>
                <div className="p-2 sm:p-3 rounded-full bg-purple-100 dark:bg-purple-900 flex-shrink-0 ml-2">
                  <CalendarDaysIcon className="h-4 w-4 sm:h-5 sm:w-5 lg:h-6 lg:w-6 text-purple-600 dark:text-purple-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-3 sm:gap-4 lg:gap-6 mb-4 sm:mb-6 lg:mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
        >
          <Card className="w-full h-full flex flex-col">
            <CardHeader className="p-3 sm:p-4 lg:p-6 pb-1 sm:pb-2 lg:pb-2">
              <CardTitle className="flex items-center space-x-2 text-sm sm:text-base lg:text-lg">
                <BarChart className="h-4 w-4 sm:h-5 sm:w-5" />
                <span>Generate Log Report</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-3 sm:p-4 lg:p-6 pt-2 sm:pt-3 lg:pt-3 flex-1 flex-col justify-between">
              <div className="space-y-2">
                <div className="space-y-1">
                  <Label htmlFor="logType" className="text-xs sm:text-sm font-medium">Report Type</Label>
                  <Select value={logType} onValueChange={setLogType}>
                    <SelectTrigger className="h-7 text-xs sm:text-sm">
                      <SelectValue placeholder="Select report type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="zone">Zone Logs</SelectItem>
                      <SelectItem value="vehicle">Vehicle Logs</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label htmlFor="selectedIdInput" className="text-xs sm:text-sm font-medium">
                    {logType === 'zone' ? 'Zone ID' : 'Vehicle ID'}
                  </Label>
                  <Input
                    id="selectedIdInput"
                    type="text"
                    value={selectedId}
                    onChange={(e) => {
                      setSelectedId(e.target.value);
                      setSelectedIdError('');
                    }}
                    placeholder={`Enter ${logType === 'zone' ? 'Zone' : 'Vehicle'} ID (e.g., ${logType === 'zone' ? 'Z001' : 'RT001'})`}
                    className="h-7 text-xs sm:text-sm"
                  />
                  {selectedIdError && <p className="text-red-500 text-xs mt-1">{selectedIdError}</p>}
                </div>
                <div className="space-y-1">
                  <Label htmlFor="startDate" className="text-xs sm:text-sm font-medium">Start Date</Label>
                  <Input type="date" id="startDate" value={startDate} onChange={(e) => { setStartDate(e.target.value); setStartDateError(''); }} className="h-7 text-xs sm:text-sm" />
                  {startDateError && <p className="text-red-500 text-xs mt-1">{startDateError}</p>}
                </div>
                <div className="space-y-1">
                  <Label htmlFor="endDate" className="text-xs sm:text-sm font-medium">End Date</Label>
                  <Input type="date" id="endDate" value={endDate} onChange={(e) => { setEndDate(e.target.value); setEndDateError(''); }} className="h-7 text-xs sm:text-sm" />
                  {endDateError && <p className="text-red-500 text-xs mt-1">{endDateError}</p>}
                </div>
              </div>
              <div className="mt-4">
                <Button onClick={handleGenerateReport} className="w-full h-7 text-xs sm:text-sm">
                  Generate Report
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
        >
          <Card className="w-full h-full flex flex-col">
            <CardHeader className="p-3 sm:p-4 lg:p-6 pb-1 sm:pb-2 lg:pb-2">
              <CardTitle className="flex items-center space-x-2 text-sm sm:text-base lg:text-lg">
                <BarChart className="h-4 w-4 sm:h-5 sm:w-5" />
                <span>Report Visualization</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-3 sm:p-4 lg:p-6 pt-2 sm:pt-3 lg:pt-3 flex-1 flex-col">
              {/* Zone Collections Chart */}
              {logType === 'zone' && zoneCollectionsChartData && (
                <div className="space-y-3 sm:space-y-4 mb-6"> {/* Added mb-6 for spacing */}
                  <h3 className="text-sm sm:text-base lg:text-lg font-semibold">Zone {selectedId} Daily Collections</h3>
                  <div className="w-full overflow-hidden">
                    <Bar
                      data={zoneCollectionsChartData}
                      options={{
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                          legend: { display: false }, // Hide legend if only one dataset
                          title: { display: true, text: 'Daily Number of Collections' }
                        },
                        scales: {
                          y: {
                            beginAtZero: true,
                            title: {
                              display: true,
                              text: 'Number of Collections'
                            }
                          }
                        }
                      }}
                      height={150} // Adjusted height for two charts
                    />
                  </div>
                </div>
              )}
              {/* Zone Weight Chart */}
              {logType === 'zone' && zoneWeightChartData && (
                <div className="space-y-3 sm:space-y-4">
                  <h3 className="text-sm sm:text-base lg:text-lg font-semibold">Zone {selectedId} Daily Weight Collected</h3>
                  <div className="w-full overflow-hidden">
                    <Bar
                      data={zoneWeightChartData}
                      options={{
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                          legend: { display: false }, // Hide legend if only one dataset
                          title: { display: true, text: 'Daily Weight Collected (kg)' }
                        },
                        scales: {
                          y: {
                            beginAtZero: true,
                            title: {
                              display: true,
                              text: 'Weight (kg)'
                            }
                          }
                        }
                      }}
                      height={150} // Adjusted height for two charts
                    />
                  </div>
                </div>
              )}
              {/* Vehicle Chart (remains single) */}
              {logType === 'vehicle' && vehicleChartData ? (
                <div className="space-y-3 sm:space-y-4">
                  <h3 className="text-sm sm:text-base lg:text-lg font-semibold">Vehicle {selectedId} Daily Weight Collected</h3>
                  <div className="w-full overflow-hidden">
                    <Bar
                      data={vehicleChartData}
                      options={{
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                          legend: { position: 'top' },
                          title: { display: true, text: 'Daily Weight Collected' }
                        }
                      }}
                      height={250}
                    />
                  </div>
                </div>
              ) : (
                <div className="text-center text-muted-foreground py-8 sm:py-12">
                  <p className="text-xs sm:text-sm">Select a report type and generate a report to see the visualization.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6, duration: 0.6 }}
      >
        <Card className="w-full">
          <CardHeader className="p-3 sm:p-4 lg:p-6">
            <CardTitle className="flex items-center space-x-2 text-sm sm:text-base lg:text-lg">
              <ClipboardList className="h-4 w-4 sm:h-5 sm:w-5" />
              <span>Recent Collection Logs</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0 sm:p-3 lg:p-6 sm:pt-0 lg:pt-0">
            <div className="overflow-x-auto w-full">
              <Table className="min-w-full">
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4">Zone ID</TableHead>
                    <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4 hidden sm:table-cell">Vehicle ID</TableHead>
                    <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4 hidden md:table-cell">Start Time</TableHead>
                    <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4 hidden lg:table-cell">End Time</TableHead>
                    <TableHead className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap">Weight (kg)</TableHead>
                    <TableHead className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoadingRecentLogs ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-6 sm:py-8 text-muted-foreground text-xs sm:text-sm">
                        Loading recent logs...
                      </TableCell>
                    </TableRow>
                  ) : paginatedRecentLogs.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-6 sm:py-8 text-muted-foreground text-xs sm:text-sm">
                        No recent logs available.
                      </TableCell>
                    </TableRow>
                  ) : (
                    paginatedRecentLogs.map((log, index) => {
                      const badgeProps = getBadgeVariantAndColor(log.status);
                      return (
                        <TableRow key={index} className="hover:bg-muted/50">
                          <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap font-medium">{log.zoneId}</TableCell>
                          <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap hidden sm:table-cell">{log.vehicleId}</TableCell>
                          <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap hidden md:table-cell">{format(new Date(log.collectionStartTime), 'MMM dd,yyyy, hh:mm a')}</TableCell>
                          <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap hidden lg:table-cell">{log.collectionEndTime ? format(new Date(log.collectionEndTime), 'MMM dd,yyyy, hh:mm a') : 'N/A'}</TableCell>
                          <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap">{log.weightCollected ?? 'N/A'}</TableCell>
                          <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap">
                            <Badge variant={badgeProps.variant} className={`text-xs ${badgeProps.className}`}>
                              {log.status}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </div>

            {/* Pagination Controls */}
            {!isLoadingRecentLogs && totalPages > 1 && (
              <div className="flex justify-center items-center space-x-2 mt-4 p-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(0, prev - 1))}
                  disabled={currentPage === 0}
                  className="h-8 w-8 p-0"
                >
                  <ArrowLeft className="h-4 w-4" />
                </Button>
                {Array.from({ length: totalPages }, (_, i) => (
                  <Button
                    key={i}
                    variant={currentPage === i ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setCurrentPage(i)}
                    className="h-8 w-8"
                  >
                    {i + 1}
                  </Button>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.min(totalPages - 1, prev + 1))}
                  disabled={currentPage === totalPages - 1}
                  className="h-8 w-8 p-0"
                >
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            )}

            {/* Mobile View - Recent Log Cards */}
            <div className="block sm:hidden mt-4">
              {isLoadingRecentLogs ? (
                <div className="text-center py-6 text-muted-foreground text-sm">Loading recent logs...</div>
              ) : paginatedRecentLogs.length > 0 && (
                <div className="space-y-3">
                  <h3 className="text-sm font-medium text-muted-foreground px-3">Log Details</h3>
                  {paginatedRecentLogs.map((log, index) => {
                    const badgeProps = getBadgeVariantAndColor(log.status);
                    return (
                      <Card key={`mobile-${index}`} className="mx-3">
                        <CardContent className="p-3">
                          <div className="space-y-2">
                            <div className="flex justify-between items-start">
                              <div className="flex-1 min-w-0">
                                <p className="font-medium text-sm">Zone: {log.zoneId}</p>
                                <p className="text-xs text-muted-foreground">Vehicle: {log.vehicleId}</p>
                              </div>
                              <Badge variant={badgeProps.variant} className={`text-xs ml-2 ${badgeProps.className}`}>
                                {log.status}
                              </Badge>
                            </div>
                            <div className="text-xs text-muted-foreground space-y-1">
                              <p>⚖️ Weight: {log.weightCollected ?? 'N/A'} kg</p>
                              <p>🕐 Start: {format(new Date(log.collectionStartTime), 'MMM dd, hh:mm a')}</p>
                              {log.collectionEndTime && (
                                <p>🕑 End: {format(new Date(log.collectionEndTime), 'MMM dd, hh:mm a')}</p>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
};

export default LogsDashboard;