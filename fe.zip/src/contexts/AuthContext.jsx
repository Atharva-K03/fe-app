import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // Dummy credentials for scheduler
  const validCredentials = {
    'W001': { password: 'admin123', name: 'Adfway', role: 'Admin' },
    'W002': { password: 'scheduler123', name: 'Atharva', role: 'Scheduler' },
    'W003': { password: "worker123", name: 'John Doe', role: 'Worker' }
  };

  useEffect(() => {
    // Check if user is already logged in
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = (empId, password) => {
    const userCredentials = validCredentials[empId];
    if (userCredentials && userCredentials.password === password) {
      const userData = {
        empId,
        name: userCredentials.name,
        role: userCredentials.role
      };
      setUser(userData);
      localStorage.setItem('user', JSON.stringify(userData));
      return { success: true };
    }
    return { success: false, error: 'Invalid credentials' };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const value = {
    user,
    login,
    logout,
    isLoading
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

