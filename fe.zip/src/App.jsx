import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { PickupProvider } from './contexts/PickupContext';
import SignIn from './components/SignIn';
import Dashboard from './components/Dashboard';
import CreatePickup from './components/CreatePickup';
import DeletePickup from './components/DeletePickup';
import UpdatePickup from './components/UpdatePickup';
import { Toaster } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';
import './App.css';

// Page transition variants
const pageVariants = {
  initial: { opacity: 0, x: 300 },
  in: { opacity: 1, x: 0 },
  out: { opacity: 0, x: -300 }
};

const pageTransition = {
  type: 'tween',
  ease: 'anticipate',
  duration: 0.5
};

function AppContent() {
  const { user, isLoading } = useAuth();
  const [currentPage, setCurrentPage] = useState('dashboard');

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-green-600 mx-auto mb-4"></div>
          <h2 className="text-xl font-semibold text-muted-foreground">Loading...</h2>
        </motion.div>
      </div>
    );
  }

  if (!user) {
    return (
      <motion.div
        initial="initial"
        animate="in"
        exit="out"
        variants={pageVariants}
        transition={pageTransition}
      >
        <SignIn onSignIn={() => setCurrentPage('dashboard')} />
      </motion.div>
    );
  }

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return (
          <Dashboard
            onCreatePickup={() => setCurrentPage('create')}
            onDeletePickup={() => setCurrentPage('delete')}
            onUpdatePickup={() => setCurrentPage('update')}
          />
        );
      case 'create':
        return (
          <CreatePickup
            onBack={() => setCurrentPage('dashboard')}
            onSuccess={() => setCurrentPage('dashboard')}
          />
        );
      case 'update':
        return (
          <UpdatePickup
            onBack={() => setCurrentPage('dashboard')}
            onSuccess={() => setCurrentPage('dashboard')}
          />
        );

      case 'delete':
        return (
          <DeletePickup
            onBack={() => setCurrentPage('dashboard')}
            onSuccess={() => setCurrentPage('dashboard')}
          />
        );
      default:
        return (
          <Dashboard
            onCreatePickup={() => setCurrentPage('create')}
            onDeletePickup={() => setCurrentPage('delete')}
            onUpdatePickup={() => setCurrentPage('update')}
          />
        );
    }
  };

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={currentPage}
        initial="initial"
        animate="in"
        exit="out"
        variants={pageVariants}
        transition={pageTransition}
      >
        {renderCurrentPage()}
      </motion.div>
    </AnimatePresence>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <PickupProvider>
          <div className="App">
            <AppContent />
            <Toaster richColors position="top-right" />
          </div>
        </PickupProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;

