import React, { createContext, useContext, useState, useEffect } from 'react';

const PickupContext = createContext();

export const usePickup = () => {
  const context = useContext(PickupContext);
  if (!context) {
    throw new Error('usePickup must be used within a PickupProvider');
  }
  return context;
};

export const PickupProvider = ({ children }) => {
  const [pickups, setPickups] = useState([]);
  const [nextPickupId, setNextPickupId] = useState(1);

  // Dummy data
  const zones = [
    { id: 'Z001', name: 'Downtown Commercial' },
    { id: 'Z002', name: 'Residential North' },
    { id: 'Z003', name: 'Industrial East' },
    { id: 'Z004', name: 'Suburban West' },
    { id: 'Z005', name: 'City Center' }
  ];

  const vehicles = [
    { id: 'V001', name: 'Truck Alpha' },
    { id: 'V002', name: 'Truck Beta' },
    { id: 'V003', name: 'Truck Gamma' },
    { id: 'V004', name: 'Truck Delta' },
    { id: 'V005', name: 'Truck Echo' }
  ];

  const workers = [
    { id: 'W001', name: 'Mike Johnson' },
    { id: 'W002', name: 'Sarah Wilson' },
    { id: 'W003', name: 'David Brown' },
    { id: 'W004', name: 'Lisa Davis' },
    { id: 'W005', name: 'Tom Miller' },
    { id: 'W006', name: 'Emma Garcia' },
    { id: 'W007', name: 'James Rodriguez' },
    { id: 'W008', name: 'Anna Martinez' }
  ];

  useEffect(() => {
    // Load initial dummy data
    const initialPickups = [
      {
        id: 'P001',
        zone: 'Z001',
        location: 'Main Street Plaza',
        startTime: '10:00',
        endTime: '11:00',
        frequency: 'Daily',
        vehicle: 'V001',
        worker1: 'W001',
        worker2: 'W002',
        status: 'Scheduled',
        createdAt: new Date().toISOString()
      },
      {
        id: 'P002',
        zone: 'Z002',
        location: 'Residential Complex A',
        startTime: '14:00',
        endTime: '15:00',
        frequency: 'Weekly',
        vehicle: 'V002',
        worker1: 'W003',
        worker2: 'W004',
        status: 'Scheduled',
        createdAt: new Date().toISOString()
      }
    ];
    setPickups(initialPickups);
    setNextPickupId(3);
  }, []);

  const createPickup = (pickupData) => {
    const newPickup = {
      ...pickupData,
      id: `P${String(nextPickupId).padStart(3, '0')}`,
      status: 'Scheduled',
      createdAt: new Date().toISOString()
    };
    setPickups(prev => [...prev, newPickup]);
    setNextPickupId(prev => prev + 1);
    return newPickup;
  };

  const deletePickup = (pickupId) => {
    setPickups(prev => prev.filter(pickup => pickup.id !== pickupId));
  };

  const getZoneName = (zoneId) => {
    const zone = zones.find(z => z.id === zoneId);
    return zone ? zone.name : 'Unknown Zone';
  };

  const getVehicleName = (vehicleId) => {
    const vehicle = vehicles.find(v => v.id === vehicleId);
    return vehicle ? vehicle.name : 'Unknown Vehicle';
  };

  const getWorkerName = (workerId) => {
    const worker = workers.find(w => w.id === workerId);
    return worker ? worker.name : 'Unknown Worker';
  };

  const value = {
    pickups,
    zones,
    vehicles,
    workers,
    createPickup,
    deletePickup,
    getZoneName,
    getVehicleName,
    getWorkerName
  };

  return (
    <PickupContext.Provider value={value}>
      {children}
    </PickupContext.Provider>
  );
};

