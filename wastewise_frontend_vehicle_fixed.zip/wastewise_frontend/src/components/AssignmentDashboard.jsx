import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ClipboardList, Plus, Edit, Trash2, Users, Route, MapPin } from 'lucide-react';
import { assignmentsAPI, handleApiError } from '../utils/api';
import { formatSuccessMessage } from '../utils/validation';
import { toast } from 'sonner';

const AssignmentDashboard = ({ onCreateAssignment, onUpdateAssignment, onDeleteAssignment }) => {
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch assignments on component mount
  useEffect(() => {
    fetchAssignments();
  }, []);

  const fetchAssignments = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Mock data for demonstration - replace with actual API call when backend is ready
      const mockAssignments = [
        {
          id: 'AS001',
          zone: 'Z001',
          route: 'RT001',
          vehicle: 'VH001',
          shift: 'Day Shift',
          firstWorker: 'W001',
          secondWorker: 'W002',
          status: 'Active'
        },
        {
          id: 'AS002',
          zone: 'Z002',
          route: 'RT002',
          vehicle: 'VH002',
          shift: 'Night Shift',
          firstWorker: 'W003',
          secondWorker: 'W004',
          status: 'Active'
        }
      ];
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setAssignments(mockAssignments);
    } catch (err) {
      const errorMessage = 'Failed to load assignments. Using mock data for demonstration.';
      setError(errorMessage);
      console.warn('Assignment API not available, using mock data:', err);
      
      // Set mock data even on error for demonstration
      setAssignments([]);
    } finally {
      setLoading(false);
    }
  };

  // Calculate dashboard statistics
  const dashboardStats = useMemo(() => {
    const totalAssignments = assignments.length;
    const uniqueRoutes = new Set(assignments.map(a => a.route)).size;
    const uniqueZones = new Set(assignments.map(a => a.zone)).size;

    return {
      totalAssignments,
      uniqueRoutes,
      uniqueZones
    };
  }, [assignments]);

  // Handle assignment deletion
  const handleDeleteAssignment = async (assignmentId) => {
    if (window.confirm('Are you sure you want to delete this assignment?')) {
      try {
        await assignmentsAPI.delete(assignmentId);
        toast.success(formatSuccessMessage('delete', 'Assignment'));
        fetchAssignments(); // Refresh the list
      } catch (err) {
        const errorMessage = handleApiError(err);
        toast.error(errorMessage);
      }
    }
  };

  // Get shift badge styling
  const getShiftBadge = (shift) => {
    const isDay = shift?.toLowerCase() === 'day';
    return {
      variant: 'default',
      className: isDay 
        ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
        : 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
    };
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="p-2 sm:p-4 lg:p-6 max-w-full overflow-hidden"
    >
      <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold mb-4 sm:mb-6 text-gray-800 dark:text-white">
        Assignment Management
      </h1>

      {/* Dashboard Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 lg:gap-6 mb-4 sm:mb-6 lg:mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.6 }}
        >
          <Card className="transition-all duration-200 hover:scale-105 hover:shadow-lg">
            <CardContent className="p-3 sm:p-4 lg:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0 flex-1">
                  <p className="text-xs sm:text-sm font-medium text-muted-foreground truncate">
                    Total Assignments
                  </p>
                  <p className="text-lg sm:text-xl lg:text-2xl font-bold">
                    {dashboardStats.totalAssignments}
                  </p>
                </div>
                <div className="p-2 sm:p-3 rounded-full bg-green-100 dark:bg-green-900 flex-shrink-0 ml-2">
                  <ClipboardList className="h-4 w-4 sm:h-5 sm:w-5 lg:h-6 lg:w-6 text-green-600 dark:text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
        >
          <Card className="transition-all duration-200 hover:scale-105 hover:shadow-lg">
            <CardContent className="p-3 sm:p-4 lg:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0 flex-1">
                  <p className="text-xs sm:text-sm font-medium text-muted-foreground truncate">
                    Number of Routes
                  </p>
                  <p className="text-lg sm:text-xl lg:text-2xl font-bold">
                    {dashboardStats.uniqueRoutes}
                  </p>
                </div>
                <div className="p-2 sm:p-3 rounded-full bg-blue-100 dark:bg-blue-900 flex-shrink-0 ml-2">
                  <Route className="h-4 w-4 sm:h-5 sm:w-5 lg:h-6 lg:w-6 text-blue-600 dark:text-blue-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
        >
          <Card className="transition-all duration-200 hover:scale-105 hover:shadow-lg">
            <CardContent className="p-3 sm:p-4 lg:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0 flex-1">
                  <p className="text-xs sm:text-sm font-medium text-muted-foreground truncate">
                    Number of Zones
                  </p>
                  <p className="text-lg sm:text-xl lg:text-2xl font-bold">
                    {dashboardStats.uniqueZones}
                  </p>
                </div>
                <div className="p-2 sm:p-3 rounded-full bg-purple-100 dark:bg-purple-900 flex-shrink-0 ml-2">
                  <MapPin className="h-4 w-4 sm:h-5 sm:w-5 lg:h-6 lg:w-6 text-purple-600 dark:text-purple-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Action Buttons */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.6 }}
        className="flex justify-center mb-8"
      >
        <div className="flex flex-col sm:flex-row gap-4 w-full max-w-4xl">
          <Button
            onClick={onCreateAssignment}
            className="flex-1 h-12 text-lg text-white transition-all duration-200 hover:scale-105 bg-green-600 hover:bg-green-700"
          >
            <Plus className="h-5 w-5 mr-2" />
            Create Assignment
          </Button>
          <Button
            onClick={onUpdateAssignment}
            className="flex-1 h-12 text-lg text-white dark:text-white transition-all duration-200 hover:scale-105 bg-yellow-500 hover:bg-yellow-600"
          >
            <Edit className="h-5 w-5 mr-2" />
            Update Assignment
          </Button>
          <Button
            onClick={onDeleteAssignment}
            className="flex-1 h-12 text-lg text-white transition-all duration-200 hover:scale-105 bg-red-500 hover:bg-red-700"
          >
            <Trash2 className="h-5 w-5 mr-2" />
            Delete Assignment
          </Button>
        </div>
      </motion.div>

      {/* Assignments Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.6 }}
      >
        <Card className="w-full">
          <CardHeader className="p-3 sm:p-4 lg:p-6">
            <CardTitle className="flex items-center space-x-2 text-sm sm:text-base lg:text-lg">
              <ClipboardList className="h-4 w-4 sm:h-5 sm:w-5" />
              <span>Assignment List</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0 sm:p-3 lg:p-6 sm:pt-0 lg:pt-0">
            {error ? (
              <div className="text-center py-8 text-red-600">
                <p>{error}</p>
                <Button 
                  onClick={fetchAssignments} 
                  variant="outline" 
                  className="mt-4"
                >
                  Retry
                </Button>
              </div>
            ) : (
              <div className="overflow-x-auto w-full">
                <Table className="min-w-full">
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4">
                        Assignment ID
                      </TableHead>
                      <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4">
                        Vehicle
                      </TableHead>
                      <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4 hidden sm:table-cell">
                        Route
                      </TableHead>
                      <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4 hidden md:table-cell">
                        Zone
                      </TableHead>
                      <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4 hidden lg:table-cell">
                        Assigned Workers
                      </TableHead>
                      <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4">
                        Shift
                      </TableHead>
                      <TableHead className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4">
                        Actions
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {assignments.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-6 sm:py-8 text-muted-foreground text-xs sm:text-sm">
                          No assignments found. Create your first assignment to get started.
                        </TableCell>
                      </TableRow>
                    ) : (
                      assignments.map((assignment) => {
                        const shiftBadge = getShiftBadge(assignment.shift);
                        return (
                          <TableRow key={assignment.assignmentId} className="hover:bg-muted/50">
                            <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap font-medium">
                              {assignment.assignmentId}
                            </TableCell>
                            <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap">
                              {assignment.vehicle}
                            </TableCell>
                            <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap hidden sm:table-cell">
                              {assignment.route}
                            </TableCell>
                            <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap hidden md:table-cell">
                              {assignment.zone}
                            </TableCell>
                            <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap hidden lg:table-cell">
                              <div className="flex flex-wrap gap-1">
                                {assignment.assignedWorkers?.map((worker, index) => (
                                  <Badge key={index} variant="secondary" className="text-xs">
                                    {worker}
                                  </Badge>
                                ))}
                              </div>
                            </TableCell>
                            <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap">
                              <Badge variant={shiftBadge.variant} className={`text-xs ${shiftBadge.className}`}>
                                {assignment.shift}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-xs sm:text-sm px-2 sm:px-4 whitespace-nowrap">
                              <div className="flex space-x-1">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => onUpdateAssignment(assignment.assignmentId)}
                                  className="h-6 w-6 p-0"
                                >
                                  <Edit className="h-3 w-3" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleDeleteAssignment(assignment.assignmentId)}
                                  className="h-6 w-6 p-0 text-red-600 border-red-600 hover:bg-red-50"
                                >
                                  <Trash2 className="h-3 w-3" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            )}

            {/* Mobile-friendly assignment cards for very small screens */}
            <div className="block sm:hidden mt-4">
              {assignments.length > 0 && (
                <div className="space-y-3">
                  <h3 className="text-sm font-medium text-muted-foreground px-3">Assignment Details</h3>
                  {assignments.map((assignment) => {
                    const shiftBadge = getShiftBadge(assignment.shift);
                    return (
                      <Card key={`mobile-${assignment.assignmentId}`} className="mx-3">
                        <CardContent className="p-3">
                          <div className="space-y-2">
                            <div className="flex justify-between items-start">
                              <div className="flex-1 min-w-0">
                                <p className="font-medium text-sm">{assignment.assignmentId}</p>
                                <p className="text-xs text-muted-foreground">Vehicle: {assignment.vehicle}</p>
                                <p className="text-xs text-muted-foreground">Route: {assignment.route}</p>
                                <p className="text-xs text-muted-foreground">Zone: {assignment.zone}</p>
                              </div>
                              <Badge variant={shiftBadge.variant} className={`text-xs ml-2 ${shiftBadge.className}`}>
                                {assignment.shift}
                              </Badge>
                            </div>
                            <div className="text-xs text-muted-foreground">
                              <p>👥 Workers: {assignment.assignedWorkers?.join(', ') || 'None'}</p>
                            </div>
                            <div className="flex space-x-2 pt-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => onUpdateAssignment(assignment.assignmentId)}
                                className="flex-1"
                              >
                                <Edit className="h-3 w-3 mr-1" />
                                Edit
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleDeleteAssignment(assignment.assignmentId)}
                                className="flex-1 text-red-600 border-red-600 hover:bg-red-50"
                              >
                                <Trash2 className="h-3 w-3 mr-1" />
                                Delete
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
};

export default AssignmentDashboard;

