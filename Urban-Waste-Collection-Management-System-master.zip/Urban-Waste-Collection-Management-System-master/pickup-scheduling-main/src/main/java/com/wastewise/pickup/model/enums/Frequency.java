package com.wastewise.pickup.model.enums;

public enum Frequency {
    DAILY,
    WEEKLY,
    MONTHLY
}
