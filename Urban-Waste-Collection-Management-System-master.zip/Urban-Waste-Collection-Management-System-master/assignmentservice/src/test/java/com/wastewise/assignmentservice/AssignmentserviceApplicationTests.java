package com.wastewise.assignmentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignmentserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
