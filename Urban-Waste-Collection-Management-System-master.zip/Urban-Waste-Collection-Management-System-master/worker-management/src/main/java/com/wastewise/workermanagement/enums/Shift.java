package com.wastewise.workermanagement.enums;

public enum Shift {
    DAY,NIGHT
}
