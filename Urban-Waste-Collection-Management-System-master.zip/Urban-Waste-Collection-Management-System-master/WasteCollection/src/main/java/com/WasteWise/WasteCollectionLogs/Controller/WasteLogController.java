package com.WasteWise.WasteCollectionLogs.Controller;

import com.WasteWise.WasteCollectionLogs.Constants.WasteLogConstants;
import com.WasteWise.WasteCollectionLogs.Dto.*;
import com.WasteWise.WasteCollectionLogs.Payload.RestResponse;
import com.WasteWise.WasteCollectionLogs.Handler.InvalidInputException;
import com.WasteWise.WasteCollectionLogs.Handler.ResourceNotFoundException;
import com.WasteWise.WasteCollectionLogs.ServiceImpl.WasteLogServiceImpl;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault; 
import org.springframework.data.domain.Sort;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger; 
import org.slf4j.LoggerFactory;
import java.time.LocalDate;



/**
 * REST Controller for managing waste collection logs.
 * This controller handles API endpoints related to starting, ending, and generating reports
 * for waste collection activities within the WasteWise application.
 * <p>
 * It leverages Spring's `@RestController` for building RESTful web services and
 * `@RequestMapping` to define the base path for all endpoints in this controller.
 * Validation for request bodies and path/request parameters is performed using
 * Jakarta Bean Validation (`@Valid`, `@Pattern`) and Spring's `@Validated`.
 * </p>
 */
@RestController
@RequestMapping("/wastewise/admin/wastelogs")
@Validated 
public class WasteLogController {
	
	 private static final Logger logger = LoggerFactory.getLogger(WasteLogController.class); 
    private final WasteLogServiceImpl wasteLogService;

    /**
     * Constructs a new WasteLogController with the given WasteLogServiceImpl.
     * Spring automatically injects the WasteLogServiceImpl dependency.
     *
     * @param wasteLogService The service responsible for handling waste log business logic.
     */
    public WasteLogController(WasteLogServiceImpl wasteLogService) {
        this.wasteLogService = wasteLogService;
        logger.info("WasteLogController initialized.");
    }

    /**
     * Accessed by Sanitary Worker
     * Initiates a new waste collection log.
     * This endpoint accepts a POST request with the details of a new waste collection.
     * The request body is validated automatically by Spring due to the `@Valid` annotation,
     * ensuring that all required fields and formats in {@link WasteLogStartRequestDTO} are met.
     *
     * @param request The {@link WasteLogStartRequestDTO} containing details such as zone ID,
     * vehicle ID, worker ID, and start time.
     * @return A {@link ResponseEntity} containing a {@link RestResponse} with the
     * details of the newly created log and an HTTP status of 201 (Created).
     * @throws InvalidInputException If any business rule validation fails (e.g., invalid ID format,
     * which should ideally be caught by @Pattern, but can also be from service).
     */
    @PreAuthorize("hasRole('SANITARY_WORKER')")
    @PostMapping("/start")
    public ResponseEntity<RestResponse<Object>> startCollection(@Valid @RequestBody WasteLogStartRequestDTO request) {
    	 logger.info("Received request to start collection: {}", request);
        WasteLogResponseDTO serviceResponse = wasteLogService.startCollection(request); // Service returns raw DTO
        
        RestResponse<Object> restResponse = new RestResponse<>(
            true,
            serviceResponse.getMessage(), 
            serviceResponse
        );
        logger.info("Collection started successfully. Response: {}", restResponse);

        return new ResponseEntity<>(restResponse, HttpStatus.CREATED);
    }

    /**
     * Accessed by Sanitary Worker
     * Completes an existing waste collection log.
     * This endpoint accepts a PUT request to update an ongoing waste collection log
     * with an end time and collected weight. The request body is validated by `@Valid`.
     *
     * @param request The {@link WasteLogUpdateRequestDTO} containing the worker ID to update,
     * the end time of collection, and the weight collected.
     * @return A {@link ResponseEntity} containing a {@link RestResponse} with the
     * updated log details and an HTTP status of 200 (OK).
     * @throws ResourceNotFoundException If the waste log with the given worker ID is not found.
     * @throws InvalidInputException If the provided end time is before the start time, or weight is invalid.
     */
    @PreAuthorize("hasRole('SANITARY_WORKER')")
    @PutMapping("/end")
    public ResponseEntity<RestResponse<Object>> endCollection(@Valid @RequestBody WasteLogUpdateRequestDTO request) {
    	  logger.info("Received request to end collection for worker ID: {}", request.getWorkerId());
        WasteLogResponseDTO serviceResponse = wasteLogService.endCollection(request); 
        RestResponse<Object> restResponse = new RestResponse<>(
            true,
            serviceResponse.getMessage(), 
            serviceResponse 
        );
        logger.info("Collection ended successfully. Response: {}", restResponse);
        return ResponseEntity.ok(restResponse);
    }
    /**
     * Accessed by Admin
     * Retrieves a daily summary report for a specific waste collection zone within a given date range.
     * This endpoint handles GET requests to provide aggregated waste collection data for a zone.
     * The `zoneId` path variable is validated using a regular expression defined in {@link WasteLogConstants}.
     * The `startDate` and `endDate` request parameters are parsed by Spring as {@link LocalDate}
     * objects using the ISO date format (YYYY-MM-DD).
     *
     * @param zoneId The unique identifier of the zone (e.g., "Z001"). Must conform to {@link WasteLogConstants#ZONE_ID_REGEX}.
     * @param startDate The start date of the reporting period in YYYY-MM-DD format.
     * @param endDate The end date of the reporting period in YYYY-MM-DD format.
     * @param pageable Pagination information, automatically provided by Spring.
     * Defaults to sorting by `date` ascending (as per business logic).
     * @return A {@link ResponseEntity} containing a {@link RestResponse} with a Page of {@link ZoneReportDTO},
     * each representing a daily summary for the specified zone, and an HTTP status of 200 (OK).
     * An empty page is returned if no logs are found for the given criteria.
     * @throws InvalidInputException If the date range is invalid (e.g., startDate is after endDate).
     * @throws jakarta.validation.ConstraintViolationException If `zoneId` does not match the required pattern.
     * @throws org.springframework.web.method.annotation.MethodArgumentTypeMismatchException If dates are not in correct format.
     */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/reports/zone")
    public ResponseEntity<RestResponse<Page<ZoneReportDTO>>> getZoneLogs( // Return type changed
            @RequestParam @Pattern(regexp = WasteLogConstants.ZONE_ID_REGEX,
                    message = "Invalid Zone ID format. Must be Z### (e.g., Z001).") String zoneId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @PageableDefault(size=10,sort = "date", direction = Sort.Direction.ASC) Pageable pageable) { // Added Pageable with fixed sort default
    	  logger.info("Received request for zone report: zoneId={}, startDate={}, endDate={}, pageable={}",
                  zoneId, startDate, endDate, pageable);
        Page<ZoneReportDTO> reportsPage = wasteLogService.getZoneLogs(zoneId, startDate, endDate, pageable); // Pass pageable

        String message = reportsPage.isEmpty() ?
                String.format(WasteLogConstants.NO_COMPLETED_LOGS_FOUND_ZONE, zoneId, startDate.toString(), endDate.toString()) :
                "Zone report generated successfully.";

        RestResponse<Page<ZoneReportDTO>> restResponse = new RestResponse<>(true, message, reportsPage); 
        logger.info("Zone report generated. Page size: {}, Total elements: {}. Response: {}",
                reportsPage.getContent().size(), reportsPage.getTotalElements(), restResponse);
        return ResponseEntity.ok(restResponse);
    }

    /**
     * Accessed by Admin
     * Retrieves collection logs for a specific vehicle within a given date range.
     * This endpoint provides detailed waste collection log entries for a particular vehicle.
     * The `vehicleId` path variable is validated using a regular expression from {@link WasteLogConstants}.
     * The `startDate` and `endDate` request parameters are parsed as {@link LocalDate} objects
     * using the ISO date format.
     *
     * @param vehicleId The unique identifier of the vehicle (e.g., "RT001" or "PT001"). Must conform to {@link WasteLogConstants#VEHICLE_ID_REGEX}.
     * @param startDate The start date of the reporting period in YYYY-MM-DD format.
     * @param endDate The end date of the reporting period in YYYY-MM-DD format.
     * @param pageable Pagination information, automatically provided by Spring.
     * Defaults to sorting by `collectionDate` ascending.
     * @return A {@link ResponseEntity} containing a {@link RestResponse} with a Page of {@link VehicleReportDTO},
     * each representing a single collection log entry for the specified vehicle, and an HTTP status of 200 (OK).
     * An empty page is returned if no logs are found.
     * @throws InvalidInputException If the date range is invalid.
     * @throws jakarta.validation.ConstraintViolationException If `vehicleId` does not match the required pattern.
     * @throws org.springframework.web.method.annotation.MethodArgumentTypeMismatchException If dates are not in correct format.
     */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/reports/vehicle")
    public ResponseEntity<RestResponse<Page<VehicleReportDTO>>> getVehicleLogs(
            @RequestParam @Pattern(regexp = WasteLogConstants.VEHICLE_ID_REGEX,
                    message = "Invalid Vehicle ID format. Must be RT### or PT### (e.g., RT001).") String vehicleId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @PageableDefault(size=10,sort = "collectionDate", direction = Sort.Direction.ASC) Pageable pageable) { 
    	 logger.info("Received request for vehicle report: vehicleId={}, startDate={}, endDate={}, pageable={}",
                 vehicleId, startDate, endDate, pageable);
        Page<VehicleReportDTO> reportsPage = wasteLogService.getVehicleLogs(vehicleId, startDate, endDate, pageable); 

        String message = reportsPage.isEmpty() ?
                String.format(WasteLogConstants.NO_COMPLETED_LOGS_FOUND_VEHICLE, vehicleId, startDate.toString(), endDate.toString()) :
                WasteLogConstants.VEHICLE_REPORT_GENERATED_SUCCESSFULLY;

        RestResponse<Page<VehicleReportDTO>> restResponse = new RestResponse<>(true, message, reportsPage);
        logger.info("Vehicle report generated. Page size: {}, Total elements: {}. Response: {}",
                reportsPage.getContent().size(), reportsPage.getTotalElements(), restResponse);
        return ResponseEntity.ok(restResponse);
    }
    /**
     * When you add a new endpoint, just add this annotation @PreAuthorize("hasRole('ADMIN')") above the method.
     */
    /**
     * Accessed by Admin
     * Retrieves the total number of completed waste collections for the current week.
     * This endpoint does not require any input parameters as it calculates based on the current date.
     *
     * @return A {@link ResponseEntity} containing a {@link RestResponse} with the total
     * number of weekly collections and an HTTP status of 200 (OK).
     */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/reports/totalCollections/weekly")
    public ResponseEntity<RestResponse<Long>> getTotalWeeklyCollections() {
        logger.info("Received request for total weekly collections report.");
        long totalCollections = wasteLogService.getTotalCollectionsForCurrentWeek();
        String message = String.format("Total weekly collections: %d", totalCollections);
        RestResponse<Long> restResponse = new RestResponse<>(true, message, totalCollections);
        logger.info("Total weekly collections report generated. Count: {}", totalCollections);
        return ResponseEntity.ok(restResponse);
    }

    /**
     * Accessed by Admin
     * Retrieves the total number of completed waste collections for the current month.
     * This endpoint does not require any input parameters as it calculates based on the current date.
     *
     * @return A {@link ResponseEntity} containing a {@link RestResponse} with the total
     * number of monthly collections and an HTTP status of 200 (OK).
     */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/reports/totalCollections/monthly")
    public ResponseEntity<RestResponse<Long>> getTotalMonthlyCollections() {
        logger.info("Received request for total monthly collections report.");
        long totalCollections = wasteLogService.getTotalCollectionsForCurrentMonth();
        String message = String.format("Total monthly collections: %d", totalCollections);
        RestResponse<Long> restResponse = new RestResponse<>(true, message, totalCollections);
        logger.info("Total monthly collections report generated. Count: {}", totalCollections);
        return ResponseEntity.ok(restResponse);
    }
    
    /**
     * Accessed by Admin
     * Retrieves the total weight collected for completed waste collections for the current week.
     * This endpoint does not require any input parameters as it calculates based on the current date.
     *
     * @return A {@link ResponseEntity} containing a {@link RestResponse} with the total
     * weekly collected weight and an HTTP status of 200 (OK).
     */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/reports/totalWeight/weekly")
    public ResponseEntity<RestResponse<Double>> getTotalWeightCollectedWeekly() {
        logger.info("Received request for total weekly weight collected report.");
        Double totalWeight = wasteLogService.getTotalWeightCollectedForCurrentWeek();
        String message = String.format("Total weekly weight collected: %.2f kg", totalWeight);
        RestResponse<Double> restResponse = new RestResponse<>(true, message, totalWeight);
        logger.info("Total weekly weight collected report generated. Weight: {} kg", totalWeight);
        return ResponseEntity.ok(restResponse);
    }


    /**
     * Accessed by Admin
     * Retrieves a paginated list of recent waste collection logs for default display on the admin dashboard.
     * Logs are ordered by `collectionStartTime` in descending order (most recent first).
     *
     * @param pageable Pagination information. Defaults to size 10, page 0, sorted by `collectionStartTime` descending.
     * @return A {@link ResponseEntity} containing a {@link RestResponse} with a Page of {@link RecentWasteLogDTO},
     * providing recent log details with a derived status.
     */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/reports/recentLogs")
    public ResponseEntity<RestResponse<Page<RecentWasteLogDTO>>> getRecentWasteLogs(
            @PageableDefault(size = 10, page = 0, sort = "collectionStartTime", direction = Sort.Direction.DESC) Pageable pageable) {
        logger.info("Received request for recent waste logs with pageable: {}", pageable);
        Page<RecentWasteLogDTO> recentLogsPage = wasteLogService.getRecentWasteLogs(pageable);

        String message = recentLogsPage.isEmpty() ?
                WasteLogConstants.NO_RECENT_LOGS_FOUND :
                "Recent waste logs retrieved successfully.";

        RestResponse<Page<RecentWasteLogDTO>> restResponse = new RestResponse<>(true, message, recentLogsPage);
        logger.info("Recent waste logs retrieved. Page size: {}, Total elements: {}. Response: {}",
                recentLogsPage.getContent().size(), recentLogsPage.getTotalElements(), restResponse);
        return ResponseEntity.ok(restResponse);
    }

}