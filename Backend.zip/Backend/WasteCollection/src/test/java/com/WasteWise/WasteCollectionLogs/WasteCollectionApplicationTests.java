package com.WasteWise.WasteCollectionLogs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WasteCollectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
