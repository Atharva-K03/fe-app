package com.wastewise.workermanagement.exception;

public class ContactInformationUsedException extends RuntimeException{
    public ContactInformationUsedException(String message) {
        super(message);
    }
}
