package com.wastewise.workermanagement.enums;

public enum WorkerStatus {
    AVAILABLE,OCCUPIED,ABSENT,DELETED
}
