package com.wastewise.pickup.model.enums;

public enum WorkerStatus {
    AVAILABLE,OCCUPIED
}
