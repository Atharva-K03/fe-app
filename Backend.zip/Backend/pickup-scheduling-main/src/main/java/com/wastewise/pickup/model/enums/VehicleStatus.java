package com.wastewise.pickup.model.enums;

public enum VehicleStatus {
    AVAILABLE,
    UNDER_MAINTENANCE,
    UNAVAILABLE
}