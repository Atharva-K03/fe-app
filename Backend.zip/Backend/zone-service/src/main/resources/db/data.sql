INSERT INTO zone (zone_id, zone_name, area_coverage) VALUES
('Z001', 'Zone A', 1000),
('Z002', 'Zone B', 2000),
('Z003', 'Zone C', 1500);
