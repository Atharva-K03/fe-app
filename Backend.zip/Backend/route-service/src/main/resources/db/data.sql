INSERT INTO route (route_id, route_name, zone_id, estimated_time, pickup_points) VALUES
('Z001-R001', 'Route A', 'Z001', 30, 'Point1, Point2'),
('Z001-R002', 'Route B', 'Z001', 45, 'Point3, Point4'),
('Z002-R001', 'Route C', 'Z002', 60, 'Point5, Point6');
